InventYU Project Backend
==================

Backend python with Flask and MySQL

Server Information
------------------
- MySQL IP: 162.243.186.103
- username: root
- port: 33067
Test